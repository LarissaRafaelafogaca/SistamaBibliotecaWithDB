package dao;

import model.Jornal;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JornalDAO {
    private Connection conn;

    public JornalDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean adicionar(Jornal jornal) {
        String sql = "INSERT INTO jornal (titulo, data_publicacao) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, jornal.getTitulo());
            stmt.setDate(2, Date.valueOf(jornal.getDataPublicacao()));
            int linhasAfetadas = stmt.executeUpdate();
            if (linhasAfetadas > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        jornal.setId(rs.getInt(1));
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao adicionar jornal: " + e.getMessage());
        }
        return false;
    }

    public Jornal buscarPorId(int id) {
        String sql = "SELECT * FROM jornal WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Jornal(
                            rs.getInt("id"),
                            rs.getString("titulo"),
                            rs.getDate("data_publicacao").toLocalDate()
                    );
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao buscar jornal: " + e.getMessage());
        }
        return null;
    }

    public List<Jornal> listar() {
        List<Jornal> jornais = new ArrayList<>();
        String sql = "SELECT * FROM jornal";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Jornal jornal = new Jornal(
                        rs.getInt("id"),
                        rs.getString("titulo"),
                        rs.getDate("data_publicacao").toLocalDate()
                );
                jornais.add(jornal);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar jornais: " + e.getMessage());
        }
        return jornais;
    }
}
