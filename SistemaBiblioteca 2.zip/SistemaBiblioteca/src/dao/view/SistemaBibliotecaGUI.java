package view;

import dao.EmprestimoDAO;
import dao.JornalDAO;
import dao.LivroDAO;
import dao.UsuarioDAO;
import model.Emprestimo;
import model.Jornal;
import model.Livro;
import model.Usuario;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class SistemaBibliotecaGUI {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(SistemaBibliotecaGUI::criarTela);
    }

    public static void criarTela() {
        JFrame frame = new JFrame("Sistema da Biblioteca");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 500);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(8, 1, 10, 10));

        JButton btnCadastrarLivro = new JButton("Cadastrar Livro");
        JButton btnCadastrarUsuario = new JButton("Cadastrar Usuário");
        JButton btnCadastrarJornal = new JButton("Cadastrar Jornal");
        JButton btnRegistrarEmprestimo = new JButton("Registrar Empréstimo");
        JButton btnListarLivros = new JButton("Listar Livros");
        JButton btnListarUsuarios = new JButton("Listar Usuários");
        JButton btnListarEmprestimos = new JButton("Listar Empréstimos");
        JButton btnListarJornais = new JButton("Listar Jornais");

        panel.add(btnCadastrarLivro);
        panel.add(btnCadastrarUsuario);
        panel.add(btnCadastrarJornal);
        panel.add(btnRegistrarEmprestimo);
        panel.add(btnListarLivros);
        panel.add(btnListarUsuarios);
        panel.add(btnListarEmprestimos);
        panel.add(btnListarJornais);

        frame.add(panel);
        frame.setVisible(true);

        // Cadastrar Livro
        btnCadastrarLivro.addActionListener(e -> {
            String titulo = JOptionPane.showInputDialog("Título do livro:");
            String autor = JOptionPane.showInputDialog("Autor:");
            String isbn = JOptionPane.showInputDialog("ISBN:");
            int ano = Integer.parseInt(JOptionPane.showInputDialog("Ano de publicação:"));

            Livro livro = new Livro(0, titulo, ano, autor, isbn);
            new LivroDAO().inserir(livro);
            JOptionPane.showMessageDialog(frame, "Livro cadastrado com sucesso!");
        });

        // Cadastrar Usuário (sem email)
        btnCadastrarUsuario.addActionListener(e -> {
            String nome = JOptionPane.showInputDialog("Nome do usuário:");

            Usuario usuario = new Usuario(0, nome);
            new UsuarioDAO().inserir(usuario);
            JOptionPane.showMessageDialog(frame, "Usuário cadastrado com sucesso!");
        });

        // Cadastrar Jornal
        btnCadastrarJornal.addActionListener(e -> {
            String titulo = JOptionPane.showInputDialog("Título do jornal:");
            String dataStr = JOptionPane.showInputDialog("Data de publicação (dd/MM/yyyy):");

            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate data = LocalDate.parse(dataStr, formatter);
                Jornal jornal = new Jornal(0, titulo, data);
                new JornalDAO().adicionar(jornal);
                JOptionPane.showMessageDialog(frame, "Jornal cadastrado com sucesso!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Data inválida. Use o formato dd/MM/yyyy.");
            }
        });

        // Registrar Empréstimo (só para livros)
        btnRegistrarEmprestimo.addActionListener(e -> {
            try {
                int idUsuario = Integer.parseInt(JOptionPane.showInputDialog("ID do usuário:"));
                int idLivro = Integer.parseInt(JOptionPane.showInputDialog("ID do livro:"));
                LocalDate hoje = LocalDate.now();
                LocalDate devolucao = hoje.plusDays(7);

                Emprestimo emp = new Emprestimo(0, idUsuario, idLivro, hoje, devolucao);
                new EmprestimoDAO().registrarEmprestimo(emp);
                JOptionPane.showMessageDialog(frame, "Empréstimo registrado com sucesso!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "ID inválido.");
            }
        });

        // Listar Livros
        btnListarLivros.addActionListener(e -> {
            List<Livro> livros = new LivroDAO().listarTodos();
            StringBuilder sb = new StringBuilder("Livros:\n");
            for (Livro l : livros) {
                sb.append("ID: ").append(l.getId())
                  .append(", Título: ").append(l.getTitulo())
                  .append(", Autor: ").append(l.getAutor())
                  .append("\n");
            }
            JOptionPane.showMessageDialog(frame, sb.toString());
        });

        // Listar Usuários
        btnListarUsuarios.addActionListener(e -> {
            List<Usuario> usuarios = new UsuarioDAO().listarTodos();
            StringBuilder sb = new StringBuilder("Usuários:\n");
            for (Usuario u : usuarios) {
                sb.append("ID: ").append(u.getId())
                  .append(", Nome: ").append(u.getNome())
                  .append("\n");
            }
            JOptionPane.showMessageDialog(frame, sb.toString());
        });

        // Listar Empréstimos
        btnListarEmprestimos.addActionListener(e -> {
            List<Emprestimo> emps = new EmprestimoDAO().listarTodos();
            StringBuilder sb = new StringBuilder("Empréstimos:\n");
            for (Emprestimo e1 : emps) {
                sb.append("ID: ").append(e1.getId())
                  .append(", Usuário ID: ").append(e1.getIdUsuario())
                  .append(", Livro ID: ").append(e1.getIdItem())
                  .append(", De: ").append(e1.getDataEmprestimo())
                  .append(", Até: ").append(e1.getDataDevolucao())
                  .append("\n");
            }
            JOptionPane.showMessageDialog(frame, sb.toString());
        });

        // Listar Jornais
        btnListarJornais.addActionListener(e -> {
            List<Jornal> jornais = new JornalDAO().listar();
            StringBuilder sb = new StringBuilder("Jornais:\n");
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            for (Jornal j : jornais) {
                sb.append("ID: ").append(j.getId())
                  .append(", Título: ").append(j.getTitulo())
                  .append(", Publicado em: ").append(j.getDataPublicacao().format(formatter))
                  .append("\n");
            }
            JOptionPane.showMessageDialog(frame, sb.toString());
        });
    }
}
