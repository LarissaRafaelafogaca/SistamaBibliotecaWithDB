package dao;

import model.Emprestimo;
import model.Livro;
import model.Usuario;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EmprestimoDAO {
    private Connection conn;

    public EmprestimoDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean adicionar(Emprestimo emprestimo) {
        String sql = "INSERT INTO emprestimo (id_usuario, id_item, data_emprestimo, data_devolucao) VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, emprestimo.getUsuario().getId());
            stmt.setInt(2, emprestimo.getLivro().getId());

            LocalDate dataEmp = emprestimo.getDataEmprestimo();
            LocalDate dataDev = emprestimo.getDataDevolucao();

            if (dataEmp != null) {
                stmt.setDate(3, Date.valueOf(dataEmp));
            } else {
                stmt.setNull(3, Types.DATE);
            }

            if (dataDev != null) {
                stmt.setDate(4, Date.valueOf(dataDev));
            } else {
                stmt.setNull(4, Types.DATE);
            }

            int linhasAfetadas = stmt.executeUpdate();
            if (linhasAfetadas > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        emprestimo.setId(rs.getInt(1));
                        return true;
                    }
                }
            }

        } catch (SQLException e) {
            System.out.println("❌ Erro ao adicionar empréstimo: " + e.getMessage());
        }

        return false;
    }

    public List<Emprestimo> listar() {
        List<Emprestimo> emprestimos = new ArrayList<>();
        String sql = "SELECT * FROM emprestimo";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                int idUsuario = rs.getInt("id_usuario");
                int idLivro = rs.getInt("id_item");

                Usuario usuario = new UsuarioDAO(conn).buscarPorId(idUsuario);
                Livro livro = new LivroDAO(conn).buscarPorId(idLivro);

                LocalDate dataEmp = rs.getDate("data_emprestimo").toLocalDate();
                LocalDate dataDev = null;

                Date dataDevolucaoDB = rs.getDate("data_devolucao");
                if (dataDevolucaoDB != null) {
                    dataDev = dataDevolucaoDB.toLocalDate();
                }

                Emprestimo emp = new Emprestimo(id, livro, usuario, dataEmp, dataDev);
                emprestimos.add(emp);
            }

        } catch (SQLException e) {
            System.out.println("❌ Erro ao listar empréstimos: " + e.getMessage());
        }

        return emprestimos;
    }
}
