package main;

import dao.ConnectionFactory;
import dao.LivroDAO;
import dao.UsuarioDAO;
import dao.EmprestimoDAO;
import model.Livro;
import model.Usuario;
import model.Emprestimo;

import java.sql.Connection;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class SistemaBiblioteca {
    public static void main(String[] args) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        try (Connection conn = ConnectionFactory.getConnection()) {
            System.out.println("Conexão com MySQL estabelecida.");

            LivroDAO livroDAO = new LivroDAO(conn);
            UsuarioDAO usuarioDAO = new UsuarioDAO(conn);
            EmprestimoDAO emprestimoDAO = new EmprestimoDAO(conn);

            Scanner sc = new Scanner(System.in);
            int opcao = -1;

            do {
                try {
                    System.out.println("\n--- MENU ---");
                    System.out.println("1 - Cadastrar Livro");
                    System.out.println("2 - Cadastrar Usuário");
                    System.out.println("3 - Realizar Empréstimo de Livro");
                    System.out.println("4 - Listar Livros");
                    System.out.println("5 - Listar Usuários");
                    System.out.println("6 - Listar Empréstimos");
                    System.out.println("0 - Sair");
                    System.out.print("Escolha: ");
                    opcao = sc.nextInt();
                    sc.nextLine(); // limpar buffer

                    switch (opcao) {
                        case 1:
                            System.out.print("Título: ");
                            String titulo = sc.nextLine();
                            System.out.print("Autor: ");
                            String autor = sc.nextLine();
                            System.out.print("Editora: ");
                            String editora = sc.nextLine();
                            System.out.print("ISBN: ");
                            String isbn = sc.nextLine();

                            Livro livro = new Livro(0, titulo, autor, editora, isbn);
                            if (livroDAO.adicionar(livro)) {
                                System.out.println("Livro cadastrado com sucesso! ID: " + livro.getId());
                            } else {
                                System.out.println("Erro ao cadastrar livro.");
                            }
                            break;

                        case 2:
                            System.out.print("Nome do Usuário: ");
                            String nome = sc.nextLine();
                            Usuario usuario = new Usuario(0, nome);
                            if (usuarioDAO.adicionar(usuario)) {
                                System.out.println("Usuário cadastrado com sucesso! ID: " + usuario.getId());
                            } else {
                                System.out.println("Erro ao cadastrar usuário.");
                            }
                            break;

                        case 3:
                            System.out.print("ID do Usuário: ");
                            int idUsuario = sc.nextInt();
                            System.out.print("ID do Livro: ");
                            int idLivro = sc.nextInt();
                            sc.nextLine();

                            Usuario u = usuarioDAO.buscarPorId(idUsuario);
                            Livro l = livroDAO.buscarPorId(idLivro);

                            if (u != null && l != null) {
                                // Aqui você pode implementar lógica para verificar se o livro já está emprestado (opcional)
                                Emprestimo emprestimo = new Emprestimo(0, l, u, LocalDate.now(), null);
                                if (emprestimoDAO.adicionar(emprestimo)) {
                                    System.out.println("Empréstimo realizado com sucesso! ID: " + emprestimo.getId());
                                } else {
                                    System.out.println("Erro ao realizar empréstimo.");
                                }
                            } else {
                                System.out.println("Usuário ou Livro inválido.");
                            }
                            break;

                        case 4:
                            System.out.println("=== Lista de Livros ===");
                            List<Livro> livros = livroDAO.listar();
                            for (Livro livroItem : livros) {
                                System.out.println(livroItem.getId() + ": " + livroItem.getTitulo() + " - " + livroItem.getAutor());
                            }
                            break;

                        case 5:
                            System.out.println("=== Lista de Usuários ===");
                            List<Usuario> usuarios = usuarioDAO.listar();
                            for (Usuario usuarioItem : usuarios) {
                                System.out.println(usuarioItem.getId() + ": " + usuarioItem.getNome());
                            }
                            break;

                        case 6:
                            System.out.println("=== Lista de Empréstimos ===");
                            List<Emprestimo> emprestimos = emprestimoDAO.listar();
                            for (Emprestimo emp : emprestimos) {
                                System.out.println(emp.getId() + ": " + emp.getUsuario().getNome() + " -> " + emp.getLivro().getTitulo() + " (Empréstimo em: " + emp.getDataEmprestimo().format(dtf) + ")");
                            }
                            break;

                        case 0:
                            System.out.println("Saindo...");
                            break;

                        default:
                            System.out.println("Opção inválida.");
                            break;
                    }

                } catch (InputMismatchException e) {
                    System.out.println("Entrada inválida, tente novamente.");
                    sc.nextLine(); // limpar buffer
                } catch (Exception e) {
                    System.out.println("Erro: " + e.getMessage());
                    e.printStackTrace();
                }
            } while (opcao != 0);

            sc.close();

        } catch (Exception e) {
            System.out.println("Erro ao conectar ao banco: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
