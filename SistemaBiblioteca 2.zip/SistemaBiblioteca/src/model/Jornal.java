package model;

import java.time.LocalDate;

public class Jornal {
    private int id;
    private String titulo;
    private LocalDate dataPublicacao;

    public Jornal() {}

    public Jornal(int id, String titulo, LocalDate dataPublicacao) {
        this.id = id;
        this.titulo = titulo;
        this.dataPublicacao = dataPublicacao;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public LocalDate getDataPublicacao() { return dataPublicacao; }
    public void setDataPublicacao(LocalDate dataPublicacao) { this.dataPublicacao = dataPublicacao; }
}
